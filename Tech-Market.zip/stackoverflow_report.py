import streamlit as st
import pandas as pd
import folium
import matplotlib.pyplot as plt
from streamlit_folium import folium_static

def show_stackoverflow_report():
    st.title("Stack Overflow Global Insights")
    
    try:
        # Load the data
        df = pd.read_csv('survey_results_public24.csv')
        # Map: Top 10 Countries Distribution
        country_counts = df['Country'].value_counts(normalize=True) * 100  # Convert to percentage
        top_10_countries = country_counts.head(10)
        
        # Create a map centered around a global location
        m = folium.Map(location=[20.5937, 78.9629], zoom_start=1)

        # Adding markers for the top 10 countries
        for country, percentage in top_10_countries.items():
            country_coords = get_country_coordinates(country)
            if country_coords:
                lat, lon = country_coords
                folium.Marker(
                    location=[lat, lon],
                    popup=f'{country}: {percentage:.2f}%',
                    icon=folium.Icon(color='blue')
                ).add_to(m)
            else:
                st.warning(f"Coordinates for {country} not found.")

        # Add default OpenStreetMap tiles with attribution
        folium.TileLayer('openstreetmap', attr='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors').add_to(m)

        # Display the map in Streamlit
        folium_static(m)
        st.write("Top 10 Countries Distribution (Bar Chart):")
        st.bar_chart(top_10_countries)

        # Developer Type Distribution (Bar Chart)
        learn_code_counts = df['DevType'].value_counts(normalize=True) * 100  # Convert to percentage
        st.write("Developer Type Distribution (Bar Chart):")
        fig, ax = plt.subplots(figsize=(10, 8))
        learn_code_counts.sort_values(ascending=True).plot(kind='barh', color='skyblue', edgecolor='black', ax=ax)
        ax.set_title('Developer Type Distribution', fontsize=16)
        ax.set_xlabel('Percentage (%)', fontsize=12)
        ax.set_ylabel('Title', fontsize=12)
        ax.grid(axis='x', linestyle='--', alpha=0.7)
        st.pyplot(fig)

        # Top 20 Programming Languages Worked With by Respondents
        languages_worked = df['LanguageHaveWorkedWith'].dropna().str.split(';').explode()
        language_counts = languages_worked.value_counts().reset_index()
        language_counts.columns = ['Language', 'RespondentCount']  
        total_respondents = df.shape[0]
        language_counts['Percentage'] = (language_counts['RespondentCount'] / total_respondents) * 100
        top_languages = language_counts.sort_values(by='Percentage', ascending=False).head(20)
        st.write("Top Programming Languages Worked With by Respondents:")
        fig, ax = plt.subplots(figsize=(10, 8))
        ax.barh(top_languages['Language'][::-1], top_languages['Percentage'][::-1], color='skyblue', edgecolor='black')
        ax.set_xlabel('Percentage of Respondents (%)')
        ax.set_title('Top Programming Languages Worked With by Respondents')
        ax.grid(axis='x', linestyle='--', alpha=0.7)
        st.pyplot(fig)

        # Top Web Frameworks Respondents Want to Work With
        web_frameworks_want = df['WebframeWantToWorkWith'].dropna().str.split(';').explode()
        total_occurrences = len(web_frameworks_want)
        framework_counts = web_frameworks_want.value_counts()
        framework_percentages = (framework_counts / total_occurrences) * 100
        framework_percentages = framework_percentages.reset_index()
        framework_percentages.columns = ['Framework', 'Percentage']
        top_frameworks = framework_percentages.sort_values(by='Percentage', ascending=False).head(20)
        st.write("Top Web Frameworks Respondents Want to Work With:")
        fig, ax = plt.subplots(figsize=(10, 8))
        ax.barh(top_frameworks['Framework'][::-1], top_frameworks['Percentage'][::-1], color='skyblue', edgecolor='black')
        ax.set_xlabel('Percentage of Respondents (%)')
        ax.set_title('Top Web Frameworks Respondents Want to Work With')
        ax.grid(axis='x', linestyle='--', alpha=0.7)
        st.pyplot(fig)

        # Top Asynchronous Tools Used (Pie Chart)
        tools_column = 'OfficeStackAsyncHaveWorkedWith'
        tools_data = df[tools_column].dropna().str.split(';').explode()
        tool_counts = tools_data.value_counts()
        tool_percentages = (tool_counts / total_respondents) * 100
        top_tools = tool_percentages.head(8)  # Select top 8 tools for the pie chart
        st.write("Top Asynchronous Tools Used (Pie Chart):")
        plt.figure(figsize=(8, 8))
        plt.pie(
            top_tools.values,                
            labels=top_tools.index,          
            autopct='%1.1f%%',               
            startangle=140,                  
            colors=plt.cm.tab20.colors,      
            wedgeprops={'edgecolor': 'black'} 
        )
        plt.title('Top Asynchronous Tools Used by Developers', fontsize=16)
        plt.tight_layout()
        st.pyplot(plt)

        # Top Platforms Used
        platforms_column = 'PlatformHaveWorkedWith'
        platforms_data = df[platforms_column].dropna().str.split(';').explode()
        platform_counts = platforms_data.value_counts()
        platform_percentages = (platform_counts / total_respondents) * 100
        top_platforms = platform_percentages.head(10)
        st.write("Top Platforms Used:")
        fig, ax = plt.subplots(figsize=(12, 8))
        ax.barh(top_platforms.index[::-1], top_platforms.values[::-1], color='skyblue', edgecolor='black')
        ax.set_xlabel('Percentage of Respondents (%)', fontsize=12)
        ax.set_title('Top Platforms Used')
        ax.grid(axis='x', linestyle='--', alpha=0.7)
        st.pyplot(fig)

        # Top Synchronous Tools Used (Pie Chart)
        tools_column = 'OfficeStackSyncHaveWorkedWith'
        tools_data = df[tools_column].dropna().str.split(';').explode()
        tool_counts = tools_data.value_counts()
        tool_percentages = (tool_counts / total_respondents) * 100
        top_tools = tool_percentages.head(8)  # Top 8 tools for pie chart
        st.write("Top Synchronous Tools Used (Pie Chart):")
        plt.figure(figsize=(10, 8))
        plt.pie(
            top_tools.values,                
            labels=top_tools.index,          
            autopct='%1.1f%%',               
            startangle=140,                  
            colors=plt.cm.Paired.colors,     
            wedgeprops={'edgecolor': 'black'} 
        )
        plt.title('Top Synchronous Tools Used by Developers', fontsize=16)
        plt.tight_layout()
        st.pyplot(plt)

        # Top AI Search Development Tools Used (Pie Chart)
        tools_column = 'AISearchDevHaveWorkedWith'
        tools_data = df[tools_column].dropna().str.split(';').explode()
        tool_counts = tools_data.value_counts()
        tool_percentages = (tool_counts / total_respondents) * 100
        top_tools = tool_percentages.head(5)  # Top 5 tools for AI search
        st.write("Top AI Search Development Tools Used (Pie Chart):")
        plt.figure(figsize=(8, 8))
        plt.pie(
            top_tools.values,                
            labels=top_tools.index,          
            autopct='%1.1f%%',               
            startangle=90,                  
            colors=plt.cm.Paired.colors,     
            wedgeprops={'edgecolor': 'black'} 
        )
        plt.title('Top AI Search Development Tools Used by Developers', fontsize=16)
        plt.tight_layout()
        st.pyplot(plt)

        # Top Employment Statuses (Bar Chart)
        tools_column = 'Employment'  # Change to the relevant column name
        tools_data = df[tools_column].dropna().str.split(';').explode()  # Process the data
        tool_counts = tools_data.value_counts()
        total_responses = len(df)
        tool_percentages = (tool_counts / total_responses) * 100
        top_tools = tool_percentages.head(10)  # Top 10 employment statuses
        st.write("Top Employment Statuses Among Respondents:")
        plt.figure(figsize=(8, 6))
        plt.barh(top_tools.index[::-1], top_tools.values[::-1], color='skyblue', edgecolor='black')
        plt.xlabel('Percentage of Respondents (%)', fontsize=12)
        plt.title('Top Employment Statuses Among Respondents', fontsize=16)
        plt.grid(axis='x', linestyle='--', alpha=0.7)
        plt.tight_layout()
        st.pyplot(plt)

        # Salary by Developer Type (Bar Chart)
        developer_types = df['DevType']
        salaries = df['ConvertedCompYearly']
        salary_by_dev_type = (
            df.groupby('DevType')['ConvertedCompYearly']
            .mean()
            .dropna()
            .sort_values(ascending=False)
        )
        st.write("Salary by Developer Type:")
        plt.figure(figsize=(10, 8))
        plt.barh(salary_by_dev_type.index, salary_by_dev_type.values, color='skyblue')
        plt.xlabel("Average Salary (USD)", fontsize=12)
        plt.ylabel("Developer Type", fontsize=12)
        plt.title("Salary by Developer Type", fontsize=16)
        plt.gca().invert_yaxis()  # Invert y-axis for descending order
        plt.tight_layout()
        st.pyplot(plt)

       
        

    except Exception as e:
        st.error(f"Error loading Stack Overflow report: {str(e)}")

# Function to get coordinates for a country
def get_country_coordinates(country):
    country_coordinates = {
        'United States': [37.0902, -95.7129],
        'United States of America': [37.0902, -95.7129],  # Full name
        'India': [20.5937, 78.9629],
        'United Kingdom': [51.5074, -0.1278],
        'United Kingdom of Great Britain and Northern Ireland': [51.5074, -0.1278],  # Full name
        'Germany': [51.1657, 10.4515],
        'Canada': [56.1304, -106.3468],
        'Australia': [-25.2744, 133.7751],
        'Brazil': [-14.2350, -51.9253],
        'France': [46.6034, 1.8883],
        'Italy': [41.8719, 12.5674],
        'Spain': [40.4637, -3.7492],
        'Ukraine': [48.3794, 31.1656],
        'Poland': [51.9194, 19.1451],
        'Netherlands': [52.1326, 5.2913]
    }
    return country_coordinates.get(country, None)

