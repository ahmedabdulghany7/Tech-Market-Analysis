import pandas as pd
import pickle
import streamlit as st

def clean_city(x):
    city_mapping = {
        'Cairo': ['Cairo', 'Cairo ', 'cairo', 'Cairo, Maadi', 'Egypt', 'Maadi', 
                    ' Cairo', 'Cai ', 'nasr city', 'Cairo, Egypt', 'CAIRO'],
        'Alexandria': ['Alexandria', 'alexandria', 'Alex', 'Alexandria, Egypt'],
        'Giza': ['Giza', '6 October', 'Jizah ', 'October', 'zayed', 'Sheikh Zayed'],
        'Smart Village': ['Smart Village', 'Smart village', 'smart village'],
        'Saudi Arabia': ['KSA', 'Riyadh', 'Jeddah', 'Saudi Arabia', 'Saudi'],
        'UAE': ['Dubai', 'Dubai ', 'Dubai & cairo', 'UAE'],
        'USA': ['USA', 'US', 'California', 'Texas', 'United States']
    }

    for city, variants in city_mapping.items():
        if any(variant in str(x) for variant in variants):  # Convert to string
            return city
    return 'Unknown (Other)'

@st.cache_data
def load_data():
    """Load and preprocess the dataset"""
    try:
        # Load the data
        df = pd.read_csv('Updated not collected without others.csv')
        
        # Clean the city column
        df['City of Company site'] = df['City of Company site'].apply(clean_city)
        
        # Convert salary to numeric, removing any non-numeric characters
        df['Salary'] = pd.to_numeric(df['Salary'].astype(str).str.replace(r'[^\d.]', ''), errors='coerce')
        
        # Fill missing values
        df['Years of Experiences '] = pd.to_numeric(df['Years of Experiences '].fillna(0), errors='coerce')
        df['Work Type'] = df['Work Type'].fillna('Unknown')
        df['What Is your Company'] = df['What Is your Company'].fillna('Other')
        
        # Remove rows with invalid salaries
        df = df[df['Salary'].notna() & (df['Salary'] > 0)]
        
        return df
    except Exception as e:
        st.error(f"Error loading data: {str(e)}")
        return None

@st.cache_resource
def load_models():
    """Load trained models and preprocessing components"""
    try:
        with open("nn_model.pkl", "rb") as f:
            nn_model = pickle.load(f)
        with open("scaler.pkl", "rb") as f:
            scaler = pickle.load(f)
        with open("label_encoders.pkl", "rb") as f:
            label_encoders = pickle.load(f)
        return nn_model, scaler, label_encoders
    except Exception as e:
        st.error(f"Error loading models: {str(e)}")
        return None, None, None