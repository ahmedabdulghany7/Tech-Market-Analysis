import pandas as pd
import numpy as np

def predict_salary(nn_model, scaler, label_encoders, title, years_exp, work_type, city, company_type):
    """Make salary predictions using the neural network model"""
    try:
        # Create input dataframe
        input_data = pd.DataFrame({
            'Title': [title],
            'Years of Experiences ': [float(years_exp)],
            'Work Type': [work_type],
            'City of Company site': [city],
            'What Is your Company': [company_type]
        })
        
        # Encode categorical variables
        input_encoded = input_data.copy()
        for col in ['Title', 'Work Type', 'City of Company site', 'What Is your Company']:
            input_encoded[col + '_encoded'] = label_encoders[col].transform(input_data[col])
        
        # Prepare features
        feature_cols = ['Years of Experiences ', 'Title_encoded', 'Work Type_encoded', 
                       'City of Company site_encoded', 'What Is your Company_encoded']
        input_features = pd.DataFrame()
        input_features['Years of Experiences '] = input_data['Years of Experiences ']
        for col in ['Title', 'Work Type', 'City of Company site', 'What Is your Company']:
            input_features[col + '_encoded'] = input_encoded[col + '_encoded']
        
        # Scale features
        input_scaled = scaler.transform(input_features)
        
        # Make prediction
        prediction = nn_model.predict(input_scaled)[0]
        
        return max(0, round(prediction, 2))  # Ensure non-negative prediction
    except Exception as e:
        return f"Prediction error: {str(e)}"