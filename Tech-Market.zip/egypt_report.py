import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load and process the data
def load_and_process_data(file_path):
    df = pd.read_csv(file_path)
    df['Years_of_Experience'] = pd.to_numeric(df['Years_of_Experience'], errors='coerce')
    df['Years_of_Experience'] = df['Years_of_Experience'].round()
    return df

def calculate_salary_statistics(df):
    # Calculate average salary by experience level
    salary_stats = pd.pivot_table(
        data=df,
        values='Salary',
        index='Years_of_Experience',
        aggfunc=lambda x: round(x.mean())
    )

    # Calculate IQR for outlier detection
    q1 = salary_stats['Salary'].quantile(0.25)
    q3 = salary_stats['Salary'].quantile(0.75)
    iqr = q3 - q1
    outlier_threshold_upper = q3 + 1.5 * iqr
    outlier_threshold_lower = q1 - 1.5 * iqr

    # Filter out the outliers
    filtered_stats = salary_stats[(salary_stats['Salary'] <= outlier_threshold_upper) & 
                                   (salary_stats['Salary'] >= outlier_threshold_lower)]
    return filtered_stats

def plot_salary_distribution(filtered_stats):
    # Assign colors based on the filtered data
    colors_filtered = ['green'] * len(filtered_stats)

    # Expand the Y-axis limits
    y_max = filtered_stats['Salary'].max() + 10000  # Add some padding

    # Plot the bar chart excluding outliers
    ax = filtered_stats['Salary'].plot(kind='bar', 
                                       title='Average Salary by Years of Experience',
                                       ylabel='Average Salary', xlabel='Years of Experience', color='lightseagreen')
    plt.ylim(0, y_max)
    st.pyplot(plt.gcf())


def plot_job_title_trends(filtered_pivot):
    # Calculate IQR for each job title and filter outliers
    for title in filtered_pivot.columns:
        q1 = filtered_pivot[title].quantile(0.25)
        q3 = filtered_pivot[title].quantile(0.75)
        iqr = q3 - q1
        outlier_threshold_upper = q3 + 1.5 * iqr
        outlier_threshold_lower = q1 - 1.5 * iqr

        # Filter out outliers and drop NaN values
        filtered_pivot[title] = filtered_pivot[title].where(
            (filtered_pivot[title] <= outlier_threshold_upper) & 
            (filtered_pivot[title] >= outlier_threshold_lower)
        ).dropna()

    # Create subplots (grid of 5 rows and 2 columns, one for each job title)
    fig, axes = plt.subplots(nrows=5, ncols=2, figsize=(20, 20))
    axes = axes.flatten()

    # Define a list of colors for the bars (cyclic)
    colors = ['lightcoral', 'lightseagreen', 'lightskyblue', 'deepskyblue', 'plum', 
              'lightseagreen', 'saddlebrown', 'saddlebrown', 'lightseagreen', 'deepskyblue']

    # Plotting each job title in its own subplot
    for i, title in enumerate(filtered_pivot.columns):
        if i >= len(axes):
            break  # Ensure we don't exceed the number of axes created

        ax = axes[i]
        data = filtered_pivot[title].dropna()  # Drop NaN values before plotting

        # Plot only if there's valid data
        if not data.empty:
            ax.bar(data.index, data.values, color=colors[i % len(colors)], edgecolor='black')
            ax.set_title(title, color='skyblue')
            ax.set_xlabel('Years of Experience', color='black')
            ax.set_ylabel('Average Salary', color='black')
            ax.set_xticks(range(len(data.index)))
            ax.set_xticklabels(data.index, rotation=45)
        else:
            ax.set_visible(False)  # Hide the subplot if there's no data

    # Adjust layout for better spacing
    plt.tight_layout()
    st.pyplot(plt.gcf())

def plot_salary_growth_trajectory(filtered_pivot):
    # Select top 10 titles based on average salary
    top_20_titles = filtered_pivot.mean().sort_values(ascending=False).head(20).index
    filtered_pivot_top_20 = filtered_pivot[top_20_titles]

    fig, ax = plt.subplots(figsize=(12, 8))
    for title in filtered_pivot_top_20.columns:
        sns.lineplot(x=filtered_pivot_top_20.index, y=filtered_pivot_top_20[title], ax=ax, label=title, marker='o')
    ax.set_title('Salary Growth Trajectory for Top 20 Job Titles by Years of Experience', fontsize=16)
    ax.set_xlabel('Years of Experience', fontsize=14)
    ax.set_ylabel('Average Salary', fontsize=14)
    plt.xticks(rotation=45)
    plt.legend(title='Job Title', bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()

    # Display the plot in Streamlit
    st.pyplot(fig)


def plot_additional_analysis(df):
    # Filter out 'Other' job title and count occurrences of job titles
    df_filtered = df[df['Title'] != 'Other']
    title_counts = df_filtered['Title'].value_counts()
    sorted_title_counts = title_counts.sort_values(ascending=False)

    # Pie chart for top 10 most common job titles
    top_10_titles = sorted_title_counts.head(10)
    fig, ax = plt.subplots(figsize=(8, 8))
    ax.pie(top_10_titles, labels=top_10_titles.index, autopct='%1.1f%%', startangle=90, wedgeprops={'width': 0.4})
    ax.set_title('Top 10 Most Common Job Titles')
    st.pyplot(fig)

    # Salary comparison by company origin (multinational vs Egyptian)
    salary_by_company_type = df.groupby("Company's_Origin")['Salary'].mean().round()
    st.subheader('Salary Comparison by Company Type')
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.pie(salary_by_company_type, labels=salary_by_company_type.index, autopct='%1.1f%%', startangle=90)
    ax.set_title('Salary Distribution by Company Type')
    st.pyplot(fig)

    # Job type distribution across locations (top 10)
    job_type_location_distribution = df.groupby(['site', 'Work Type']).size().unstack(fill_value=0).head(10)
    st.subheader("Top 10 Locations: Job Type Distribution")
    fig, ax = plt.subplots(figsize=(10, 6))
    job_type_location_distribution.plot(kind='bar', stacked=True, ax=ax)
    ax.set_title("Top 10 Locations: Job Type Distribution")
    ax.set_xlabel("Location")
    ax.set_ylabel("Number of Jobs")
    plt.xticks(rotation=45)
    plt.tight_layout()
    st.pyplot(fig)

    # Salary and job count analysis across locations (top 10)
    location_salary_stats = df.groupby('site').agg(Average_Salary=('Salary', 'mean'), Job_Count=('Title', 'count')).sort_values(by='Average_Salary', ascending=False).head(10)
    st.subheader("Top 10 Locations: Salary and Job Count")
    fig, ax = plt.subplots(figsize=(10, 6))
    location_salary_stats.plot(kind="bar", y=["Average_Salary", "Job_Count"], secondary_y="Job_Count", ax=ax)
    ax.set_title("Top 10 Locations: Average Salary and Job Count")
    ax.set_xlabel("Location")
    plt.xticks(rotation=45)
    plt.tight_layout()
    st.pyplot(fig)

def show_egypt_report():
    st.title("Egypt Tech Market Report")

    try:
        # Load data
        df = load_and_process_data('my_data.csv')

        # Analyze salary statistics
        filtered_stats = calculate_salary_statistics(df)
        plot_salary_distribution(filtered_stats)

        # Prepare pivot table for job title trends
        filtered_pivot = pd.pivot_table(
            df,
            values='Salary',
            index='Years_of_Experience',
            columns='Title',
            aggfunc='mean'
        )

        # Plot job title trends
        plot_job_title_trends(filtered_pivot)

        # Plot salary growth trajectory
        plot_salary_growth_trajectory(filtered_pivot)

        # Additional analysis
        plot_additional_analysis(df)

    except Exception as e:
        st.error(f"Error loading Egypt report: {str(e)}")
