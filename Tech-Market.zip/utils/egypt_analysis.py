import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

def load_egypt_data():
    return pd.read_csv('Updated not collected without others.csv')

def create_salary_distribution(df):
    fig = px.histogram(
        df, 
        x="Salary",
        title="Salary Distribution in Egypt",
        labels={"Salary": "Salary (EGP)", "count": "Number of Employees"}
    )
    return fig

def create_experience_salary_correlation(df):
    fig = px.scatter(
        df,
        x="Years of Experiences ",
        y="Salary",
        title="Experience vs Salary Correlation",
        labels={"Years of Experiences ": "Years of Experience", "Salary": "Salary (EGP)"}
    )
    return fig

def create_city_salary_boxplot(df):
    fig = px.box(
        df,
        x="City of Company site",
        y="Salary",
        title="Salary Distribution by City",
        labels={"City of Company site": "City", "Salary": "Salary (EGP)"}
    )
    return fig

def get_key_metrics(df):
    return {
        "avg_salary": df["Salary"].mean(),
        "median_salary": df["Salary"].median(),
        "top_city": df["City of Company site"].mode()[0],
        "avg_experience": df["Years of Experiences "].mean()
    }