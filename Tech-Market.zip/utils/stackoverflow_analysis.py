import pandas as pd
import plotly.express as px

def load_stackoverflow_data():
    return pd.read_csv('stack_overflow_developer_survey2024.csv')

def create_language_popularity(df):
    lang_data = df["LanguageHaveWorkedWith"].str.get_dummies(sep=';')
    popularity = lang_data.sum().sort_values(ascending=False)
    
    fig = px.bar(
        x=popularity.index[:10],
        y=popularity.values[:10],
        title="Top 10 Programming Languages",
        labels={"x": "Language", "y": "Number of Developers"}
    )
    return fig

def create_remote_work_distribution(df):
    remote_counts = df["RemoteWork"].value_counts()
    
    fig = px.pie(
        values=remote_counts.values,
        names=remote_counts.index,
        title="Remote Work Distribution"
    )
    return fig

def create_salary_by_experience(df):
    fig = px.scatter(
        df,
        x="YearsCodePro",
        y="ConvertedCompYearly",
        title="Salary vs Professional Coding Experience",
        labels={"YearsCodePro": "Years of Professional Experience", 
               "ConvertedCompYearly": "Annual Salary (USD)"}
    )
    return fig

def get_global_metrics(df):
    return {
        "top_language": df["LanguageHaveWorkedWith"].str.get_dummies(sep=';').sum().idxmax(),
        "remote_percentage": (df["RemoteWork"] == "Remote").mean() * 100,
        "avg_experience": pd.to_numeric(df["YearsCodePro"], errors='coerce').mean(),
        "most_common_role": df["DevType"].mode()[0]
    }