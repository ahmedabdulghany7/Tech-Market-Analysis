import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
import pickle
from src.data_loader import load_data, load_models
from src.predictor import predict_salary
from egypt_report import show_egypt_report
from stackoverflow_report import show_stackoverflow_report

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Page config
st.set_page_config(
    page_title="Tech Market Analysis",
    page_icon="📊",
    layout="wide"
)

df = load_data()
nn_model, scaler, label_encoders = load_models()

# Sidebar navigation
st.sidebar.title("Navigation")
page = st.sidebar.radio("Go to", ["Home", "Salary Prediction", "Egypt Report", "Stack Overflow Report", "Demand Forecasting Models"])

# Home page
if page == "Home":
    st.title("Tech Market Analysis Dashboard")
    st.write("Welcome to the Tech Market Analysis Dashboard. This tool provides insights into:")
    
    col1, col2 = st.columns(2)
    with col1:
        st.info("""
        ### Market Reports
        - Detailed Egypt tech market analysis
        - Global insights from Stack Overflow
        - Comprehensive market trends
        """)
    
    with col2:
        st.info("""
        ### Interactive Tools
        - Salary prediction model
        - Market demand forecasting
        - Technology adoption trends
        """)

elif page == "Salary Prediction":
    st.header("🚀 Tech Salary Predictor in Egypt")
    
    # Load the model and encoders
    try:
        with open('nn_model.pkl', 'rb') as f:
            rf_model = pickle.load(f)
        with open('label_encoders.pkl', 'rb') as f:
            encoders = pickle.load(f)
        
        # Input form
        col1, col2 = st.columns(2)
        
        with col1:
            title = st.selectbox(
                "Job Title",
                sorted(df['Title'].unique())
            )
            years_exp = st.slider("Years of Experience", 0, 20, 5)
            
        with col2:
            work_type = st.selectbox(
                "Work Type",
                sorted(df['Work Type'].unique())
            )
            city = st.selectbox(
                "City",
                sorted(df['City of Company site'].unique())
            )
            
        company_type = st.selectbox(
            "Company Type",
            sorted(df['What Is your Company'].unique())
        )
        
        if st.button("Predict Salary"):
            try:
                prediction = predict_salary(rf_model, scaler, encoders, title, years_exp, work_type, city, company_type)
                
                # Display prediction
                st.success(f"Predicted Salary: {prediction:,.2f} EGP")
                
            except Exception as e:
                st.error("Error making prediction. Please try again.")
                
    except FileNotFoundError:
        st.error("Model files not found. Please ensure the models are properly trained and saved.")

elif page == "Egypt Report":
    show_egypt_report()

elif page == "Stack Overflow Report":
    show_stackoverflow_report()
    
elif page == "Demand Forecasting Models":
   
    st.header("Demand Forecasting Models")

    # Visualizations
    tab1, tab2, tab3, tab4,tab5 = st.tabs(["Programming Languages", "Development Tools", 
                                      "AI/ML Tools", "Learning Trends",
                                      "Remote Work Infrastructure"])
    with tab1:
        st.header("Demand Forecasting Models")
        
    with tab2:
        st.header("Demand Forecasting Models")

    with tab3:
        st.header("Demand Forecasting Models")
        

    with tab4:
        st.header("Demand Forecasting Models")
    
    with tab5:
        st.header("Demand Forecasting Models")
      